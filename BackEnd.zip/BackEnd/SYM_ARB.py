#!/usr/bin/env python
# coding: utf-8

# In[1]:


import speech_recognition as sr
r=sr.Recognizer()

while True :
    with sr.Microphone() as src:
        print('say something ....')
        r.adjust_for_ambient_noise(src , duration=1)

        myaudio=r.listen(src)
        mytext=r.recognize_google(myaudio,language="ar-EG,en-US")
        mytext=mytext.lower()
        print(mytext)


# In[ ]:




