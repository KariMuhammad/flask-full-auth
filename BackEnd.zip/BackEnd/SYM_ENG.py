#!/usr/bin/env python
# coding: utf-8

# In[8]:


import speech_recognition as sr
r=sr.Recognizer()

while True :
    with sr.Microphone() as src:
        print('say something ....')
        r.adjust_for_ambient_noise(src , duration=1)

        myaudio=r.listen(src)
        mytext=r.recognize_google(myaudio)
        mytext=mytext.lower()
        print(mytext)


# In[6]:


get_ipython().system('pip install PyAudio')


# In[ ]:




